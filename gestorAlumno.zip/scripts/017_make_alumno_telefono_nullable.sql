-- Make telefono column nullable in alumno table
ALTER TABLE alumno ALTER COLUMN telefono DROP NOT NULL;
